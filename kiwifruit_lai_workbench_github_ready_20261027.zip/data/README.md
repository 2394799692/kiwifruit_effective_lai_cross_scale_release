# Released modeling table

`LAI_Final_17cols.csv` is a processed, de-identified tree-level modeling table containing **82 valid samples** and **17 columns** used by the public analysis scripts.

Columns:

- `LAI`: ground-observed optically derived Effective LAI used as the response variable.
- `crown radius`: canopy structural descriptor (m).
- `Tex_Cor`, `Tex_Con`, `Tex_Ene`, `Tex_Hom`, `Tex_ASM`, `Tex_Dis`: NIR-derived GLCM texture metrics.
- `NDVI`, `RVI`, `DVI`, `RDVI`, `OSAVI`, `GNDVI`, `NDRE`, `CI_re`, `MSR_re`: spectral vegetation indices.

The table does **not** contain sample-tree names, personal information, RTK coordinates, raw imagery, or the full grid-level prediction database. The abbreviated column name `LAI` refers to the optically derived **Effective LAI** defined in the manuscript.
