# Results tables

The CSV tables below contain the processed numerical outputs corresponding to the manuscript's model comparisons and the within-orchard correction analyses.

| File | Contents |
| --- | --- |
| `Table2_Feature_Subsets.csv` | Feature-subset comparison, LOOCV metrics, AIC and VIF |
| `Table3_NIR_RGB_Texture_Comparison.csv` | Radius with NIR, grayscale, red, green and blue texture descriptors |
| `Table4_Model_Hyperparameters.csv` | Selected parameters for PLSR, Linear SVR, RF and BPNN |
| `Table5_Cross_Validation_Stability.csv` | LOOCV and repeated k-fold model comparison |
| `Radius_TexCor_Fixed_Parameters.csv` | Controlled Radius-only vs Radius + Tex_Cor model comparison |
| `Radius_TexCor_Increment_Analysis.csv` | Paired LOOCV absolute-error test and partition-stability analysis |
| `Table6_Spatial_Holdout_Summary.csv` | Five-block distribution metrics for correction methods |
| `Table6_Spatial_Holdout_Fold_Metrics.csv` | Per-block evaluation metrics |
| `Table6_Spatial_Holdout_Parameters.csv` | Per-block source/target anchors and correction parameters |
| `Fig12_Distribution_Statistics.csv` | 82-tree ground sample and matched 158,604-cell raw/corrected grid distributions |

The fixed-parameter analysis uses C = 0.1 and epsilon = 0.05 for both feature sets. The NIR–RGB table records independently tuned configurations, with the NIR and blue comparison sharing the selected C = 0.1, epsilon = 0.05 setting.
