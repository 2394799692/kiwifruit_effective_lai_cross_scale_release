# Related Chinese invention patent application

The cross-scale LAI mapping workflow in this repository is related to the following Chinese invention patent application:

- **Chinese title:** 棚架式种植园的 LAI 跨尺度制图方法及装置
- **English descriptive translation:** Method and device for cross-scale LAI mapping in trellised plantations
- **Application number:** **202610573929.6**
- **Internal application reference:** **P2610010**
- **Filing date:** **April 28, 2026**
- **Applicant:** 中国农业科学院农业资源与农业区划研究所 / Institute of Agricultural Resources and Regional Planning, Chinese Academy of Agricultural Sciences
- **Current status:** **substantive examination stage; patent pending**

## Official status documents included

1. `CN2026105739296_Acceptance_Notice_2026-04-28.pdf`  
   CNIPA patent application acceptance notice dated April 28, 2026.

2. `CN2026105739296_Substantive_Examination_Notice_2026-07-24.pdf`  
   CNIPA notice confirming that the application entered substantive examination on July 24, 2026.

The acceptance notice records that the filing contained claims, specification, drawings, abstract, request documents, and a substantive-examination request. The subsequent CNIPA notice confirms that the application entered the substantive examination stage.

## Relationship to the scientific workflow

The patent application covers a cross-scale LAI mapping concept that includes grid generation from UAV multispectral orthomosaics, reconstruction of geometric information from local vegetation-index accumulation, extraction of texture features, object-scale LAI inversion, and statistical linear correction of grid-scale predictions.

The scientific article and this repository provide an academic implementation and empirical evaluation of related components under mature-stage bagged trellised kiwifruit conditions. The scientific manuscript and the patent application serve different purposes and should not be treated as identical technical documents.

## Intellectual-property notice

The patent application is pending and has not been granted. Inclusion of patent-status documents and public scientific code is intended to document the relationship between the research workflow and the associated intellectual-property filing. Public availability does not imply transfer, waiver, or grant of patent rights or commercial-use rights.

For research collaboration, additional data access, commercial use, or technology-transfer questions, contact:

**Dr. Wenjie Li**  
Email: **17395844880@163.com**
