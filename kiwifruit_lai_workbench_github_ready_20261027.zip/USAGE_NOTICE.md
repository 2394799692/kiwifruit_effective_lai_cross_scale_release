# Usage and intellectual-property notice

This repository is released as a **public reference implementation** accompanying the associated scientific study. Its purpose is to support methodological transparency, academic inspection, comparison, teaching, and research collaboration.

The repository is not intended to be a frozen archive of every internal project file, nor does the lightweight public package by itself guarantee exact reproduction of every numerical result, table, or figure in the article. Exact numerical reproduction of the orchard-scale mapping stages may require the original UAV raster products, RTK coordinates, intermediate grid tables, and a closely matched software environment.

## Patent-related notice

Parts of the cross-scale LAI mapping workflow are associated with the pending Chinese invention patent application **202610573929.6**, titled **“棚架式种植园的 LAI 跨尺度制图方法及装置”** (*Method and device for cross-scale LAI mapping in trellised plantations*).

The application was accepted by the China National Intellectual Property Administration (CNIPA) on **April 28, 2026** and entered the **substantive examination stage on July 24, 2026**. The application remains pending and has not been granted.

Public availability of source code, processed scientific data, documentation, or patent-status materials in this repository does **not** constitute a transfer, waiver, or grant of patent rights, technology-transfer rights, or commercial-use rights. No open-source license is granted by this release unless a separate license file is added by the rights holder.

For commercial use, technology transfer, expanded data access, or research collaboration, please contact:

**Dr. Wenjie Li**  
Email: **17395844880@163.com**
