# Release manifest

## Core code

- `scripts/01_Data_Analysis_Feature_Selection.py`
- `scripts/02_Model_Training_Comparison.py`
- `scripts/03_SVR_Formula_Extraction.py`
- `scripts/04_Mapping_and_Correction.py`
- `scripts/05_MAUP_Correction_Analysis.py`
- `scripts/06_MeanP99_Spatial_Holdout_and_Mapping.py`

## Released processed data

- `data/LAI_Final_17cols.csv` — 82 samples × 17 columns, de-identified modeling table.

## Patent status documents

- `patent/CN2026105739296_Acceptance_Notice_2026-04-28.pdf`
- `patent/CN2026105739296_Substantive_Examination_Notice_2026-07-24.pdf`

## Documentation

- `README.md`
- `USAGE_NOTICE.md`
- `RELEASE_NOTES.md`
- `docs/METHOD_WORKFLOW.md`
- `docs/PAPER_TO_CODE_MAP.md`
- `docs/REPOSITORY_SCOPE.md`
- `data/README.md`
- `data_access/UAV_DATA.md`
- `patent/README.md`
- `CITATION.cff`

## R3 supplementary data and result tables

- `data/LAI_RGB_Texture_Comparison_82.csv`
- `scripts/07_Radius_TexCor_Fixed_Parameter_Ablation.py`
- `scripts/08_NIR_Blue_Texture_Comparison.py`
- `scripts/09_Fig12_Distribution_Plot.py`
- `results/` (CSV tables for manuscript Tables 2–6 and Fig. 12)
- `figures/Fig12_R3_final.png`, `figures/Fig12_R3_final.pdf`
