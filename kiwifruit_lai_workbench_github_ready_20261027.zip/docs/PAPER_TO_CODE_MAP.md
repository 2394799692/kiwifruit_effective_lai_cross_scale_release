# Manuscript-to-code and results map

| Manuscript analysis | Scripts | Results |
| --- | --- | --- |
| Feature correlations and subset comparison (Table 2) | `scripts/01_Data_Analysis_Feature_Selection.py` | `results/Table2_Feature_Subsets.csv` |
| Four regression algorithms, model configurations and repeated CV (Tables 4–5) | `scripts/02_Model_Training_Comparison.py` | `results/Table4_Model_Hyperparameters.csv`, `results/Table5_Cross_Validation_Stability.csv` |
| Final Linear SVR equation | `scripts/03_SVR_Formula_Extraction.py` | Fitted parameters in README |
| Fixed-parameter Radius/Tex_Cor ablation | `scripts/07_Radius_TexCor_Fixed_Parameter_Ablation.py` | `results/Radius_TexCor_*.csv` |
| NIR–RGB texture comparison (Table 3) | `scripts/08_NIR_Blue_Texture_Comparison.py` (NIR/blue subset) | `results/Table3_NIR_RGB_Texture_Comparison.csv` |
| Orchard grid prediction and Mean-P99 correction | `scripts/04_Mapping_and_Correction.py`, `scripts/05_MAUP_Correction_Analysis.py` | Grid outputs from the mapping workflow |
| Within-orchard five-block correction-parameter evaluation (Table 6) | `scripts/06_MeanP99_Spatial_Holdout_and_Mapping.py` | `results/Table6_*.csv` |
| Ground/raw/corrected LAI distribution (Fig. 12) | `scripts/09_Fig12_Distribution_Plot.py` | `figures/Fig12_R3_final.*`, `results/Fig12_Distribution_Statistics.csv` |
