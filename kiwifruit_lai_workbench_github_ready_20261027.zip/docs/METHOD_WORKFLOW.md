# Method workflow

This note maps the public code to the main workflow described in the revised manuscript.

## A. Tree-scale modeling

1. Start from the processed 82-sample table.
2. Compare the correlations of crown radius, six NIR GLCM texture metrics, and nine spectral indices with Effective LAI.
3. Use the low-dimensional `crown radius + Tex_Cor` feature pair for the final model comparison.
4. Compare PLSR, Linear SVR, RF, and BPNN under LOOCV.
5. Fit the final Linear SVR with `C = 0.1` and `epsilon = 0.05` and convert the standardized coefficients back to the original feature scale.

## B. Grid-scale transfer

1. Generate a 0.5-m orchard grid.
2. Exclude non-vegetated background using NDVI-based screening.
3. Calculate local cumulative NDVI as a structural proxy input.
4. Estimate grid-scale crown radius from a project-specific relationship between local cumulative NDVI and crown radius.
5. Calculate NIR texture correlation for the local grid neighborhood.
6. Apply the selected tree-scale Linear SVR to obtain raw grid-level Effective LAI predictions.

## C. Mean-P99 correction

Use the ground-reference mean and P99 as target anchors and the raw grid-prediction mean and P99 as source anchors:

```text
alpha = (P99_obs - mean_obs) / (P99_pred - mean_pred)
beta  = mean_obs - alpha * mean_pred
LAI_cor = alpha * LAI_pred + beta
```

## D. Spatial holdout evaluation

1. Project tree coordinates into a common projected CRS.
2. Fit the first principal spatial axis from the tree coordinates.
3. Order the trees along this axis and divide them into five balanced contiguous blocks.
4. Assign grid cells to the same spatial blocks.
5. Hold out one block at a time.
6. Estimate correction parameters from the remaining four blocks.
7. Evaluate direct upscaling, mean-shift correction, and Mean-P99 correction in the held-out block.
8. Summarize absolute mean bias, absolute P95 error, quantile RMSE, and Wasserstein distance as mean ± SD across the five blocks.

This is a within-orchard spatial evaluation rather than an external multi-orchard validation.
