# Repository resources

This repository contains processed Effective LAI feature tables for 82 kiwifruit trees, core tree-scale modeling scripts, orchard mapping and Mean-P99 correction scripts, supplementary fixed-parameter and texture-source analyses, manuscript result tables, and the revised Fig. 12 image and plotting code.

Spatial scripts accept user-supplied aligned NDVI/NIR rasters, grid-prediction tables, and RTK coordinate inputs through command-line arguments. See `README.md` for commands and `examples/` for input layouts.

The `results/` directory includes Tables 2–6 and associated validation summaries. `docs/PAPER_TO_CODE_MAP.md` links each analysis to its scripts and result files.
