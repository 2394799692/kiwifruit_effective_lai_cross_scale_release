"""
Feature correlation and feature-screening analysis for UAV-based kiwifruit LAI inversion.

This script reads a tabular feature dataset, computes Pearson correlations between
LAI and candidate variables, and generates summary tables and publication-ready
correlation plots.

Default input:
    ../data/LAI_Final_17cols.csv

Main outputs:
    feature_correlation_matrix.csv
    feature_lai_correlation_rank.csv
    Fig_Correlation_Heatmap.png
    Fig_LAI_Correlation_Ranking.png
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Compute feature correlations and rank candidate variables for LAI inversion."
    )
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("data/LAI_Final_17cols.csv"),
        help="Path to the tabular dataset containing LAI and candidate features.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("outputs/01_feature_selection"),
        help="Directory used to save correlation tables and figures.",
    )
    parser.add_argument(
        "--target",
        type=str,
        default="LAI",
        help="Name of the response variable column.",
    )
    return parser.parse_args()


def infer_feature_type(feature_name: str) -> str:
    """Assign each feature to a broad feature group used in the manuscript."""
    name = feature_name.lower()
    if "radius" in name:
        return "Structural"
    if name.startswith("tex") or "texture" in name:
        return "Texture"
    return "Spectral"


def validate_columns(df: pd.DataFrame, required: Iterable[str]) -> None:
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {missing}")


def plot_heatmap(corr: pd.DataFrame, output_path: Path) -> None:
    plt.figure(figsize=(12, 10))
    sns.set_theme(style="white", font_scale=1.0)
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(
        corr,
        mask=mask,
        annot=True,
        fmt=".2f",
        cmap="RdBu_r",
        vmin=-1,
        vmax=1,
        center=0,
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.7, "label": "Pearson correlation"},
    )
    plt.title("Correlation matrix of LAI and candidate features", fontsize=15, pad=20)
    plt.xticks(rotation=45, ha="right")
    plt.yticks(rotation=0)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_lai_ranking(rank_df: pd.DataFrame, output_path: Path) -> None:
    plot_df = rank_df.sort_values("abs_r", ascending=True)
    plt.figure(figsize=(8, max(5, 0.35 * len(plot_df))))
    sns.barplot(data=plot_df, x="r", y="feature", hue="feature_type", dodge=False)
    plt.axvline(0, color="black", linewidth=1)
    plt.xlabel("Pearson correlation with LAI")
    plt.ylabel("Feature")
    plt.title("Feature-LAI correlation ranking")
    plt.legend(title="Feature group", frameon=False)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    plt.close()


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    if not args.data.exists():
        raise FileNotFoundError(f"Input data file not found: {args.data}")

    df = pd.read_csv(args.data)
    validate_columns(df, [args.target])

    numeric_df = df.select_dtypes(include=[np.number]).copy()
    validate_columns(numeric_df, [args.target])

    corr = numeric_df.corr(method="pearson")
    corr.to_csv(args.output_dir / "feature_correlation_matrix.csv")

    lai_corr = corr[args.target].drop(labels=[args.target]).dropna()
    rank_df = (
        pd.DataFrame({"feature": lai_corr.index, "r": lai_corr.values})
        .assign(abs_r=lambda x: x["r"].abs())
        .assign(feature_type=lambda x: x["feature"].map(infer_feature_type))
        .sort_values("abs_r", ascending=False)
        .reset_index(drop=True)
    )
    rank_df.to_csv(args.output_dir / "feature_lai_correlation_rank.csv", index=False)

    plot_heatmap(corr, args.output_dir / "Fig_Correlation_Heatmap.png")
    plot_lai_ranking(rank_df, args.output_dir / "Fig_LAI_Correlation_Ranking.png")

    print("Feature correlation analysis completed.")
    print(f"Number of samples: {len(df)}")
    print("Top-ranked features by absolute Pearson correlation with LAI:")
    print(rank_df.head(10).to_string(index=False))
    print(f"Outputs saved to: {args.output_dir}")


if __name__ == "__main__":
    main()
