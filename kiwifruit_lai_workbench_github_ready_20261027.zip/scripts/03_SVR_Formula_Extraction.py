"""
Extract the original-scale formula from a linear SVR LAI inversion model.

The linear SVR is fitted with standardized predictors. This script transforms the
coefficients back to the original feature scale so that the model can be reported
as a simple linear expression.

Default input:
    ../data/LAI_Final_17cols.csv

Main outputs:
    linear_svr_formula.txt
    linear_svr_coefficients.csv
"""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import List

import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, LeaveOneOut
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Extract the original-scale formula from linear SVR.")
    parser.add_argument("--data", type=Path, default=Path("data/LAI_Final_17cols.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/03_svr_formula"))
    parser.add_argument("--target", type=str, default="LAI")
    parser.add_argument(
        "--features",
        nargs="+",
        default=["crown radius", "Tex_Cor"],
        help="Feature columns used by the linear SVR model.",
    )
    parser.add_argument("--joblib-temp-dir", type=Path, default=Path("outputs/joblib_temp"))
    return parser.parse_args()


def validate_columns(df: pd.DataFrame, required: List[str]) -> None:
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {missing}")


def fit_linear_svr_with_grid_search(X: pd.DataFrame, y: pd.Series):
    model = make_pipeline(StandardScaler(), SVR(kernel="linear"))
    params = {
        "svr__C": [0.1, 1, 10, 50, 100, 200, 500],
        "svr__epsilon": [0.001, 0.01, 0.05, 0.1],
    }
    grid = GridSearchCV(
        model,
        params,
        cv=LeaveOneOut(),
        scoring="neg_mean_squared_error",
        n_jobs=-1,
    )
    grid.fit(X, y)
    return grid


def extract_original_scale_coefficients(best_pipeline) -> tuple[np.ndarray, float]:
    scaler = best_pipeline.named_steps["standardscaler"]
    svr = best_pipeline.named_steps["svr"]

    scaled_weights = svr.coef_[0]
    scaled_intercept = float(svr.intercept_[0])
    feature_mean = scaler.mean_
    feature_std = scaler.scale_

    original_weights = scaled_weights / feature_std
    original_intercept = scaled_intercept - float(np.sum(scaled_weights * feature_mean / feature_std))
    return original_weights, original_intercept


def format_formula(feature_names: List[str], weights: np.ndarray, intercept: float) -> str:
    display_names = {
        "crown radius": "CR",
        "Tex_Cor": "TC",
    }
    terms = []
    for feature_name, weight in zip(feature_names, weights):
        label = display_names.get(feature_name, feature_name)
        sign = "+" if weight >= 0 else "-"
        terms.append((sign, abs(weight), label))

    first_sign, first_weight, first_label = terms[0]
    formula = f"LAI = {'-' if first_sign == '-' else ''}{first_weight:.4f} * {first_label}"
    for sign, weight, label in terms[1:]:
        formula += f" {sign} {weight:.4f} * {label}"
    formula += f" {'+' if intercept >= 0 else '-'} {abs(intercept):.4f}"
    return formula


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.joblib_temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["JOBLIB_TEMP_FOLDER"] = str(args.joblib_temp_dir.resolve())

    if not args.data.exists():
        raise FileNotFoundError(f"Input data file not found: {args.data}")

    df = pd.read_csv(args.data)
    validate_columns(df, [args.target] + args.features)
    df = df.dropna(subset=[args.target] + args.features).copy()

    X = df[args.features]
    y = df[args.target]

    print("Fitting linear SVR with LOOCV grid search...")
    grid = fit_linear_svr_with_grid_search(X, y)
    weights, intercept = extract_original_scale_coefficients(grid.best_estimator_)
    formula = format_formula(args.features, weights, intercept)

    coefficients = pd.DataFrame(
        {
            "feature": args.features,
            "coefficient_original_scale": weights,
        }
    )
    coefficients.loc[len(coefficients)] = ["Intercept", intercept]

    coefficients.to_csv(args.output_dir / "linear_svr_coefficients.csv", index=False)
    with open(args.output_dir / "linear_svr_formula.txt", "w", encoding="utf-8") as f:
        f.write("Best parameters:\n")
        f.write(str(grid.best_params_))
        f.write("\n\nOriginal-scale linear SVR formula:\n")
        f.write(formula + "\n")

    print("SVR formula extraction completed.")
    print(f"Best parameters: {grid.best_params_}")
    print(formula)
    print(f"Outputs saved to: {args.output_dir}")


if __name__ == "__main__":
    main()
