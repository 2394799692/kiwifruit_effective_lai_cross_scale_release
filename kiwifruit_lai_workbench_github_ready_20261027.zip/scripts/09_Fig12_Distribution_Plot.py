"""Rebuild CEA Fig.12 from the saved calibration-grid table, without modifying sources.

Python 3.10, numpy, pandas, scipy, matplotlib, Pillow. Use --grid to specify the saved orchard prediction table; --ground and
--output may be supplied to override the repository defaults.
Run this script from its own delivery directory. Never uses simulated data.
"""
from pathlib import Path
import argparse, hashlib, json, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.stats import gaussian_kde


def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for buf in iter(lambda:f.read(1<<20),b''): h.update(buf)
    return h.hexdigest()

def describe(name, a, kind, mask_id):
    return {'Dataset': name, 'N':len(a), 'Mean':np.mean(a), 'Median':np.median(a),
            'SD_sample_ddof1':np.std(a,ddof=1), 'P95':np.quantile(a,.95),
            'P99':np.quantile(a,.99), 'Minimum':np.min(a), 'Maximum':np.max(a),
            'Grid_ID_set_SHA256':mask_id, 'Identical_grid_IDs_to_raw': ('Not applicable' if name=='Ground Observed' else ('No' if 'OLD' in name else 'Yes')), 'Clipped_0_to_6':kind,
            'Additional_corrected_threshold': 'Yes >1' if 'OLD' in name else 'No'}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--ground',type=Path,default=Path(__file__).resolve().parents[1] / 'data' / 'LAI_Final_17cols.csv')
    ap.add_argument('--grid',type=Path,required=True,help='Saved grid-level LAI_Pred and LAI_Cor table')
    ap.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1] / 'outputs' / '09_fig12')
    args=ap.parse_args(); out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    for path in [args.ground, args.grid]:
        if not path.is_file(): raise FileNotFoundError(f'Required input missing: {path}')
    ground_df=pd.read_csv(args.ground); grid=pd.read_csv(args.grid)
    ground=ground_df['LAI'].to_numpy(dtype=float)
    assert len(ground)==82 and np.isfinite(ground).all()
    assert {'Lon','Lat','LAI_Pred','LAI_Cor'}.issubset(grid.columns)
    # The file is the previously generated vegetation-grid table; do not infer a
    # new vegetation mask. Use its rows with finite raw prediction and raw >2.5.
    mask=np.isfinite(grid['LAI_Pred']) & (grid['LAI_Pred']>2.5)
    selected=grid.loc[mask,['Lon','Lat','LAI_Pred','LAI_Cor']].copy()
    selected.insert(0,'source_row_0_based',np.flatnonzero(mask.to_numpy()))
    assert len(selected)==158604 and np.isfinite(selected.to_numpy(dtype=float)).all()
    assert not selected.duplicated(['Lon','Lat']).any()
    raw=selected['LAI_Pred'].to_numpy(dtype=float)
    corrected=selected['LAI_Cor'].to_numpy(dtype=float)
    assert len(raw)==len(corrected) and (corrected>=0).all() and (corrected<=6).all()
    ids=selected[['source_row_0_based','Lon','Lat']].to_csv(index=False,float_format='%.12f',lineterminator='\n').encode('utf-8')
    raw_ids=hashlib.sha256(ids).hexdigest(); cor_ids=hashlib.sha256(ids).hexdigest(); assert raw_ids==cor_ids
    # Verify saved corrected values using full original anchors and the epsilon
    # in the identified historical mapping candidate; no new fitting is used.
    mu_obs=ground.mean(); p99_obs=np.percentile(ground,99)
    mu_raw=raw.mean(); p99_raw=np.percentile(raw,99)
    alpha=(p99_obs-mu_obs)/(p99_raw-mu_raw+1e-8); beta=mu_obs-alpha*mu_raw
    recomputed=np.clip(alpha*raw+beta,0,6); delta=float(np.max(np.abs(corrected-recomputed)))
    if delta>1e-6: raise ValueError(f'Saved correction does not match historical candidate: {delta}')
    old_cor=corrected[corrected>1.0]
    old_ids=selected.loc[corrected>1.0,['source_row_0_based','Lon','Lat']].to_csv(index=False,float_format='%.12f',lineterminator='\n').encode('utf-8')
    old_id_digest=hashlib.sha256(old_ids).hexdigest()
    stats=pd.DataFrame([describe('Ground Observed',ground,'Not applicable',''),
                        describe('Grid Raw',raw,'Not applicable',raw_ids),
                        describe('Grid Corrected',corrected,'Yes, saved original',cor_ids),
                        describe('Grid Corrected OLD >1',old_cor,'Yes, saved original',old_id_digest)])
    stats.to_csv(out/'Fig12_statistics_comparison.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
    print(stats[['Dataset','N','Mean','Median','SD_sample_ddof1','P95','P99','Minimum','Maximum']].to_string(index=False))
    print('same grid IDs:',raw_ids==cor_ids,'zero:',int(np.sum(corrected==0)),'removed by old >1:',len(corrected)-len(old_cor),'max formula delta:',delta)
    manifest={'ground_path':str(args.ground),'ground_sha256':digest(args.ground),
              'grid_path':str(args.grid),'grid_sha256':digest(args.grid),'n_source_grid_rows':len(grid),
              'calibration_filter':'finite LAI_Pred and LAI_Pred > 2.5 in existing vegetation-grid table',
              'n_ground':len(ground),'n_raw':len(raw),'n_corrected':len(corrected),
              'grid_identity':'same dataframe row, unique longitude/latitude, same ordered row and coordinates',
              'grid_identity_sha256':raw_ids,'old_corrected_filter':'LAI_Cor > 1.0',
              'n_old_corrected':len(old_cor),'n_correction_zeros':int(np.sum(corrected==0)),
              'n_correction_sixes':int(np.sum(corrected==6)),
              'alpha_candidate_with_eps_1e-8':alpha,'beta_candidate_with_eps_1e-8':beta,
              'max_abs_difference_saved_vs_candidate':delta,'plot_arrays_used_in_both_panels':True,
              'kde':'Gaussian scipy.stats.gaussian_kde, Scott bandwidth, 1200 x points, no artificial filtering; finite plot range -0.08 to 4.5; not boundary-corrected',
              'boxplot':'Matplotlib standard Tukey 1.5 IQR whiskers, means from same arrays, all outliers shown',
              'package_versions':{'python':sys.version,'matplotlib':matplotlib.__version__,'numpy':np.__version__,'pandas':pd.__version__}}
    (out/'Fig12_provenance.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    colors=['#404040','#D62728','#2CA02C']; faces=['#E0E0E0','#FFCCCC','#CCFFCC']; arr=[ground,raw,corrected]
    with plt.rc_context({'font.family':'serif','font.serif':['Times New Roman'], 'axes.unicode_minus':False,
                         'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                         'font.size':12,'figure.facecolor':'white','savefig.facecolor':'white'}):
        fig,(ax1,ax2)=plt.subplots(1,2,figsize=(12,5.12),layout='constrained')
        xx=np.linspace(-0.08,4.5,1200)
        for i,(values,color,linestyle) in enumerate(zip(arr,colors,['-','--','-'])):
            kde=gaussian_kde(values,bw_method='scott'); yy=kde(xx)
            label=['Ground Observed (n = 82)','Grid Raw (n = 158,604)','Grid Corrected (n = 158,604)'][i]
            ax1.plot(xx,yy,color=color,linestyle=linestyle,linewidth=2.0,label=label)
            if i==0:ax1.fill_between(xx,yy,color=color,alpha=.2)
            manifest.setdefault('kde_bandwidth',{})[label]=float(np.sqrt(kde.covariance[0,0]))
        # Triangle marks the discrete mass at zero, not a density estimate.
        ax1.plot(0,0,marker='^',markersize=6.5,markerfacecolor=colors[2],markeredgecolor='white',markeredgewidth=.5,clip_on=False,zorder=8)
        ax1.set(xlim=(-0.08,4.5),xlabel='LAI Value',ylabel='Density');ax1.set_ylim(bottom=0)
        ax1.legend(loc='upper left',frameon=False,fontsize=10.5)
        bp=ax2.boxplot(arr,patch_artist=True,tick_labels=['Ground\nObserved','Grid\nRaw','Grid\nCorrected'],widths=.5,showmeans=False,
                       flierprops=dict(marker='o',markerfacecolor='gray',markeredgecolor='none',markersize=2,alpha=.4,linestyle='none'),
                       medianprops=dict(color='black',linewidth=1.5),boxprops=dict(linewidth=1.2),whiskerprops=dict(linewidth=1.2),capprops=dict(linewidth=1.2))
        for patch,color in zip(bp['boxes'],faces):patch.set(facecolor=color,edgecolor='black')
        means=[np.mean(x) for x in arr]
        ax2.plot([1,2,3],means,marker='D',markersize=5.5,linestyle='none',markerfacecolor='#00BFFF',markeredgecolor='black',markeredgewidth=.8,zorder=10)
        ax2.set_ylabel('LAI Value');ax2.set_ylim(-.15,4.5)
        ax2.legend(handles=[Line2D([0],[0],marker='D',color='w',label='Mean',markerfacecolor='#00BFFF',markeredgecolor='black',markersize=6),
                            Line2D([0],[0],marker='o',color='w',label='Outliers',markerfacecolor='gray',markeredgecolor='none',markersize=5,alpha=.6)],
                   loc='upper right',frameon=False,fontsize=11,ncol=2)
        for label,ax in zip(['(a)','(b)'],(ax1,ax2)):
            ax.text(.02,.98,label,transform=ax.transAxes,ha='left',va='top',fontsize=14,fontweight='bold',bbox=dict(facecolor='white',edgecolor='none',alpha=.9,pad=1))
            ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False);ax.grid(True,linestyle=':',alpha=.4);ax.set_axisbelow(True)
            ax.xaxis.label.set_fontweight('bold');ax.yaxis.label.set_fontweight('bold')
        # Keep the panel tag clear of the legend.
        ax1.legend(loc='upper left',bbox_to_anchor=(.06,1.0),frameon=False,fontsize=10.5)
        ax2.xaxis.grid(False)
        for ext in ['png','pdf','svg']:
            fig.savefig(out/f'Fig12_R3_final.{ext}',dpi=600,facecolor='white')
        plt.close(fig)
    (out/'Fig12_provenance.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    print('Outputs saved:',out)
if __name__=='__main__':main()
