"""
Grid-scale LAI mapping and Mean+P99 cross-scale correction.

This script applies the selected linear SVR model to a UAV orthomosaic grid and
then corrects the mapped LAI distribution using a two-point moment-matching
strategy constrained by the ground-observed mean and the 99th percentile (P99).

Required raster inputs are not included in the small tabular-data release. Use the
UAV multispectral orthomosaic products described in the manuscript or update the
paths through command-line arguments.

Main outputs:
    Map_Grid_Data_Corrected.csv
    Fig_Orchard_LAI_Map.png
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import List, Tuple

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.tri as tri
import numpy as np
import pandas as pd
import rasterio
from rasterio.warp import transform_geom
from skimage.feature import graycomatrix, graycoprops
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate grid-scale LAI maps and apply Mean+P99 correction.")
    parser.add_argument("--train-data", type=Path, default=Path("data/LAI_Final_17cols.csv"))
    parser.add_argument("--ndvi", type=Path, required=True, help="Path to the NDVI raster.")
    parser.add_argument("--nir", type=Path, required=True, help="Path to the NIR reflectance raster.")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/04_mapping"))
    parser.add_argument(
        "--radius-calibration-data",
        type=Path,
        default=None,
        help=(
            "Optional CSV containing Sum_NDVI and crown radius for fitting the "
            "grid-scale structural-proxy relationship. If omitted, the training "
            "table is used only when it already contains Sum_NDVI."
        ),
    )
    parser.add_argument(
        "--allow-median-radius-fallback",
        action="store_true",
        help=(
            "Allow a demonstration-only fallback to the median training crown "
            "radius when no Sum_NDVI calibration table is available. This fallback "
            "does not reproduce the manuscript's structural-proxy reconstruction."
        ),
    )
    parser.add_argument("--grid-step-m", type=float, default=0.5)
    parser.add_argument("--buffer-radius-m", type=float, default=1.3)
    parser.add_argument("--veg-threshold", type=float, default=0.45)
    parser.add_argument("--ndvi-nonveg-threshold", type=float, default=0.35)
    parser.add_argument("--mask-lai-min", type=float, default=2.5)
    parser.add_argument("--clip-min", type=float, default=0.0)
    parser.add_argument("--clip-max", type=float, default=6.0)
    return parser.parse_args()


def validate_columns(df: pd.DataFrame, required: List[str]) -> None:
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {missing}")


def fit_lai_model(df: pd.DataFrame):
    validate_columns(df, ["LAI", "crown radius", "Tex_Cor"])
    X = df[["crown radius", "Tex_Cor"]]
    y = df["LAI"]
    model = make_pipeline(StandardScaler(), SVR(kernel="linear", C=0.1, epsilon=0.05))
    model.fit(X, y)
    return model


def fit_radius_model(df: pd.DataFrame):
    if "Sum_NDVI" not in df.columns:
        return None
    valid_df = df.dropna(subset=["Sum_NDVI", "crown radius"])
    if len(valid_df) < 3:
        return None
    return LinearRegression().fit(valid_df[["Sum_NDVI"]].values, valid_df[["crown radius"]].values)


def calculate_texture_correlation(nir_window: np.ndarray) -> float:
    """Calculate four-direction NIR GLCM correlation using 32 gray levels.

    The public implementation follows the manuscript settings: ROI/window-specific
    min-max normalization, 32-level quantization, pixel distance = 1, angles =
    0, 45, 90, and 135 degrees, symmetric and normalized GLCMs, and averaging
    across directions.
    """
    valid = np.isfinite(nir_window) & (nir_window > 0)
    if valid.sum() < 10:
        return np.nan

    values = nir_window[valid]
    min_value = float(np.nanmin(values))
    max_value = float(np.nanmax(values))
    if max_value <= min_value:
        return np.nan

    quantized = np.zeros_like(nir_window, dtype=np.uint8)
    quantized_values = np.clip(
        ((values - min_value) / (max_value - min_value) * 31), 0, 31
    ).astype(np.uint8)
    quantized[valid] = quantized_values

    angles = [0.0, np.pi / 4.0, np.pi / 2.0, 3.0 * np.pi / 4.0]
    glcm = graycomatrix(
        quantized,
        distances=[1],
        angles=angles,
        levels=32,
        symmetric=True,
        normed=True,
    )
    correlations = graycoprops(glcm, "correlation")[0, :]
    return float(np.nanmean(correlations))


def mean_p99_correction(raw_lai: np.ndarray, ground_lai: np.ndarray, clip_range: Tuple[float, float]) -> np.ndarray:
    valid_raw = raw_lai[np.isfinite(raw_lai)]
    if len(valid_raw) == 0:
        return raw_lai

    raw_mean = float(np.nanmean(valid_raw))
    raw_p99 = float(np.nanpercentile(valid_raw, 99))
    ground_mean = float(np.nanmean(ground_lai))
    ground_p99 = float(np.nanpercentile(ground_lai, 99))

    denominator = raw_p99 - raw_mean
    if abs(denominator) < 1e-8:
        corrected = raw_lai - raw_mean + ground_mean
    else:
        slope = (ground_p99 - ground_mean) / denominator
        intercept = ground_mean - slope * raw_mean
        corrected = slope * raw_lai + intercept

    return np.clip(corrected, clip_range[0], clip_range[1])


def create_lai_map(grid_df: pd.DataFrame, output_path: Path) -> None:
    valid = grid_df.dropna(subset=["x", "y", "LAI_Cor"])
    if len(valid) < 3:
        print("Not enough valid grid points to create a map.")
        return

    x = valid["x"].values
    y = valid["y"].values
    z = valid["LAI_Cor"].values

    triangulation = tri.Triangulation(x, y)
    fig, ax = plt.subplots(figsize=(9, 8))
    contour = ax.tricontourf(triangulation, z, levels=20, cmap="viridis")
    cbar = plt.colorbar(contour, ax=ax, label="LAI", shrink=0.7)
    cbar.ax.tick_params(labelsize=10)
    ax.set_xlabel("Distance in x direction (m)")
    ax.set_ylabel("Distance in y direction (m)")
    ax.set_title("Grid-scale corrected LAI distribution")
    ax.xaxis.set_major_locator(ticker.MultipleLocator(10))
    ax.yaxis.set_major_locator(ticker.MultipleLocator(10))
    ax.set_aspect("equal", adjustable="box")
    plt.tight_layout()
    plt.savefig(output_path, dpi=600, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    for path in [args.train_data, args.ndvi, args.nir]:
        if not path.exists():
            raise FileNotFoundError(f"Required file not found: {path}")

    train_df = pd.read_csv(args.train_data)
    lai_model = fit_lai_model(train_df)

    radius_source = train_df
    if args.radius_calibration_data is not None:
        if not args.radius_calibration_data.exists():
            raise FileNotFoundError(
                f"Radius calibration file not found: {args.radius_calibration_data}"
            )
        radius_source = pd.read_csv(args.radius_calibration_data)

    radius_model = fit_radius_model(radius_source)
    if radius_model is None and not args.allow_median_radius_fallback:
        raise ValueError(
            "Grid-scale crown-radius reconstruction requires a table containing "
            "both 'Sum_NDVI' and 'crown radius'. Supply --radius-calibration-data "
            "or use --allow-median-radius-fallback only for a demonstration run."
        )

    with rasterio.open(args.ndvi) as src_ndvi, rasterio.open(args.nir) as src_nir:
        ndvi = src_ndvi.read(1).astype(float)
        nir = src_nir.read(1).astype(float)
        row_step = max(1, int(args.grid_step_m / abs(src_ndvi.transform.e)))
        col_step = max(1, int(args.grid_step_m / abs(src_ndvi.transform.a)))
        radius_px = max(1, int(args.buffer_radius_m / abs(src_ndvi.transform.a)))

        rows = np.arange(0, ndvi.shape[0], row_step)
        cols = np.arange(0, ndvi.shape[1], col_step)
        records = []

        print("Scanning UAV grid...")
        for row in rows:
            for col in cols:
                center_ndvi = ndvi[row, col]
                if not np.isfinite(center_ndvi) or center_ndvi < args.ndvi_nonveg_threshold:
                    continue

                r0 = max(0, row - radius_px)
                r1 = min(ndvi.shape[0], row + radius_px)
                c0 = max(0, col - radius_px)
                c1 = min(ndvi.shape[1], col + radius_px)

                sub_ndvi = ndvi[r0:r1, c0:c1]
                sum_ndvi = float(np.nansum(sub_ndvi[sub_ndvi > args.veg_threshold]))

                if radius_model is not None:
                    pred_radius = float(radius_model.predict([[sum_ndvi]])[0][0])
                    pred_radius = float(np.clip(pred_radius, 0.5, 3.5))
                else:
                    pred_radius = float(train_df["crown radius"].median())

                sub_nir = nir[r0:r1, c0:c1]
                tex_cor = calculate_texture_correlation(sub_nir)
                if not np.isfinite(tex_cor):
                    continue

                pred_lai = float(lai_model.predict(pd.DataFrame({"crown radius": [pred_radius], "Tex_Cor": [tex_cor]}))[0])
                x_coord, y_coord = src_ndvi.xy(row, col)

                records.append(
                    {
                        "x": x_coord,
                        "y": y_coord,
                        "row": int(row),
                        "col": int(col),
                        "Sum_NDVI": sum_ndvi,
                        "crown_radius_pred": pred_radius,
                        "Tex_Cor": tex_cor,
                        "LAI_Pred": pred_lai,
                    }
                )

    grid_df = pd.DataFrame(records)
    grid_df.loc[grid_df["LAI_Pred"] <= args.mask_lai_min, "LAI_Pred"] = np.nan
    grid_df["LAI_Cor"] = mean_p99_correction(
        grid_df["LAI_Pred"].values,
        train_df["LAI"].values,
        clip_range=(args.clip_min, args.clip_max),
    )

    csv_path = args.output_dir / "Map_Grid_Data_Corrected.csv"
    grid_df.to_csv(csv_path, index=False)
    create_lai_map(grid_df, args.output_dir / "Fig_Orchard_LAI_Map.png")

    print("Mapping and correction completed.")
    print(f"Grid records: {len(grid_df)}")
    print(f"Output CSV: {csv_path}")


if __name__ == "__main__":
    main()
