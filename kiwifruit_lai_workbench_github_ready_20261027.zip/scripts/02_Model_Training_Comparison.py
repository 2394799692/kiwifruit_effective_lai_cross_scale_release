"""
Model training and comparison for UAV-based single-plant LAI inversion.

The script compares PLSR, linear SVR, Random Forest, and BPNN models using
leave-one-out cross-validation (LOOCV). It saves model metrics, predictions,
best hyperparameters, and a 2 x 2 observed-vs-predicted figure.

Default input:
    ../data/LAI_Final_17cols.csv

Main outputs:
    model_comparison_metrics.csv
    model_best_parameters.csv
    model_loocv_predictions.csv
    Fig_Model_Comparison.png
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import pandas as pd
from scipy.stats import linregress
from sklearn.cross_decomposition import PLSRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, LeaveOneOut, cross_val_predict
from sklearn.neural_network import MLPRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train and compare LAI inversion models.")
    parser.add_argument("--data", type=Path, default=Path("data/LAI_Final_17cols.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/02_model_comparison"))
    parser.add_argument("--target", type=str, default="LAI")
    parser.add_argument(
        "--features",
        nargs="+",
        default=["crown radius", "Tex_Cor"],
        help="Feature columns used for model training.",
    )
    parser.add_argument(
        "--joblib-temp-dir",
        type=Path,
        default=Path("outputs/joblib_temp"),
        help="ASCII-only temporary directory for joblib parallel processing.",
    )
    return parser.parse_args()


def validate_columns(df: pd.DataFrame, required: List[str]) -> None:
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {missing}")


def build_model_grid() -> List[Dict]:
    return [
        {
            "name": "PLSR",
            "estimator": make_pipeline(StandardScaler(), PLSRegression()),
            "params": {"plsregression__n_components": [1, 2]},
        },
        {
            "name": "SVR",
            "estimator": make_pipeline(StandardScaler(), SVR(kernel="linear")),
            "params": {
                "svr__C": [0.1, 1, 10, 50, 100, 200, 500],
                "svr__epsilon": [0.001, 0.01, 0.05, 0.1],
            },
        },
        {
            "name": "RF",
            "estimator": RandomForestRegressor(random_state=42),
            "params": {
                "n_estimators": [100, 200],
                "max_depth": [3, 5, 10],
                "min_samples_leaf": [1, 2],
            },
        },
        {
            "name": "BPNN",
            "estimator": make_pipeline(
                StandardScaler(), MLPRegressor(max_iter=3000, random_state=42)
            ),
            "params": {
                "mlpregressor__hidden_layer_sizes": [(5,), (10,), (20,)],
                "mlpregressor__alpha": [0.01, 0.001],
            },
        },
    ]


def compute_metrics(y_true: pd.Series, y_pred: np.ndarray) -> Dict[str, float]:
    rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
    sd = float(np.std(y_true, ddof=1))
    return {
        "R2": float(r2_score(y_true, y_pred)),
        "RMSE": rmse,
        "nRMSE_percent": float(rmse / np.mean(y_true) * 100),
        "RPD": float(sd / rmse),
    }


def plot_model_comparison(pred_df: pd.DataFrame, metrics_df: pd.DataFrame, output_path: Path) -> None:
    plt.rcParams["font.family"] = "serif"
    plt.rcParams["font.serif"] = ["Times New Roman", "DejaVu Serif"]
    plt.rcParams["axes.unicode_minus"] = False
    plt.rcParams["font.size"] = 12
    plt.rcParams["axes.linewidth"] = 1.2

    model_names = [col.replace("_Pred", "") for col in pred_df.columns if col.endswith("_Pred")]
    fig, axes = plt.subplots(2, 2, figsize=(11, 11))
    axes = axes.flatten()
    y_obs = pred_df["Observed"]

    axis_min = 0.0
    axis_max = max(4.5, float(np.nanmax([y_obs.max()] + [pred_df[f"{m}_Pred"].max() for m in model_names])))

    for ax, model_name in zip(axes, model_names):
        y_pred = pred_df[f"{model_name}_Pred"]
        metric_row = metrics_df.loc[metrics_df["Model"] == model_name].iloc[0]

        ax.plot([axis_min, axis_max], [axis_min, axis_max], "--", color="gray", linewidth=1.5, alpha=0.7)
        ax.scatter(y_obs, y_pred, s=42, facecolor="#87CEFA", edgecolor="black", linewidth=0.7, alpha=0.9)

        slope, intercept, _, _, _ = linregress(y_obs, y_pred)
        x_line = np.array([axis_min, axis_max])
        ax.plot(x_line, slope * x_line + intercept, color="#D62728", linewidth=1.5)

        text = (
            f"R² = {metric_row['R2']:.3f}\n"
            f"RMSE = {metric_row['RMSE']:.3f}\n"
            f"RPD = {metric_row['RPD']:.3f}"
        )
        ax.text(0.05, 0.95, text, transform=ax.transAxes, va="top", ha="left", fontsize=11)
        ax.set_title(model_name, fontweight="bold")
        ax.set_xlabel("Observed LAI")
        ax.set_ylabel("Predicted LAI")
        ax.set_xlim(axis_min, axis_max)
        ax.set_ylim(axis_min, axis_max)
        ax.xaxis.set_major_locator(ticker.MultipleLocator(1.0))
        ax.yaxis.set_major_locator(ticker.MultipleLocator(1.0))
        ax.grid(True, linestyle=":", alpha=0.4)

    plt.tight_layout()
    plt.savefig(output_path, dpi=600, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    args.joblib_temp_dir.mkdir(parents=True, exist_ok=True)
    os.environ["JOBLIB_TEMP_FOLDER"] = str(args.joblib_temp_dir.resolve())

    if not args.data.exists():
        raise FileNotFoundError(f"Input data file not found: {args.data}")

    df = pd.read_csv(args.data)
    validate_columns(df, [args.target] + args.features)
    df = df.dropna(subset=[args.target] + args.features).copy()

    X = df[args.features]
    y = df[args.target]
    loo = LeaveOneOut()

    prediction_df = pd.DataFrame({"Observed": y.values})
    metrics_records = []
    param_records = []

    print("Starting LOOCV model comparison...")
    print(f"Samples: {len(df)}")
    print(f"Features: {args.features}")

    for setup in build_model_grid():
        name = setup["name"]
        print(f"Tuning {name}...")
        grid = GridSearchCV(
            setup["estimator"],
            setup["params"],
            cv=loo,
            scoring="neg_mean_squared_error",
            n_jobs=-1,
        )
        grid.fit(X, y)
        y_pred = cross_val_predict(grid.best_estimator_, X, y, cv=loo, n_jobs=-1)
        prediction_df[f"{name}_Pred"] = y_pred

        metrics = compute_metrics(y, y_pred)
        metrics_records.append({"Model": name, **metrics})
        param_records.append({"Model": name, "Best parameters": json.dumps(grid.best_params_)})
        print(f"  Best parameters: {grid.best_params_}")
        print(f"  R2={metrics['R2']:.3f}, RMSE={metrics['RMSE']:.3f}, RPD={metrics['RPD']:.3f}")

    metrics_df = pd.DataFrame(metrics_records).sort_values("RPD", ascending=False)
    params_df = pd.DataFrame(param_records)

    prediction_df.to_csv(args.output_dir / "model_loocv_predictions.csv", index=False)
    metrics_df.to_csv(args.output_dir / "model_comparison_metrics.csv", index=False)
    params_df.to_csv(args.output_dir / "model_best_parameters.csv", index=False)
    plot_model_comparison(prediction_df, metrics_df, args.output_dir / "Fig_Model_Comparison.png")

    print("Model comparison completed.")
    print(metrics_df.to_string(index=False))
    print(f"Outputs saved to: {args.output_dir}")


if __name__ == "__main__":
    main()
