#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mean + P99 cross-scale correction, spatial holdout evaluation, and mapping.

Anonymous public-release script for the revised manuscript workflow.

Inputs
------
1. Ground/modeling table containing LAI. It may also contain RTK_E and RTK_N.
2. Optional spatial table containing RTK_E and RTK_N when coordinates are not
   included in the modeling table. If both tables contain ID, they are merged by
   ID; otherwise, rows are matched in their existing order.
3. Grid table containing Lon, Lat, and LAI_Pred. An existing LAI_Cor column is
   optional and is used only to verify reproduction of the original correction.

Default repository layout
-------------------------
data/LAI_Final_17cols.csv
data/LAI_Spatial_Coordinates.csv
outputs/04_mapping/Map_Grid_Data_Corrected.csv

Example
-------
python scripts/06_MeanP99_Spatial_Holdout_and_Mapping.py \
  --ground-data data/LAI_Final_17cols.csv \
  --spatial-data data/LAI_Spatial_Coordinates.csv \
  --grid-data outputs/04_mapping/Map_Grid_Data_Corrected.csv \
  --output-dir outputs/06_meanp99_holdout

The five-block experiment evaluates correction parameters in spatially held-out
regions of the same orchard. It is not a cross-orchard or multitemporal external
validation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, Iterable, List, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.stats import gaussian_kde, wasserstein_distance
from sklearn.decomposition import PCA


METHOD_ORDER = [
    "Direct upscaling",
    "Mean-shift correction",
    "Mean + P99 correction",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Apply Mean + P99 correction, perform five-block spatial holdout "
            "evaluation, and generate corrected Effective LAI outputs."
        )
    )
    parser.add_argument(
        "--ground-data",
        type=Path,
        default=Path("data/LAI_Final_17cols.csv"),
    )
    parser.add_argument(
        "--spatial-data",
        type=Path,
        default=Path("data/LAI_Spatial_Coordinates.csv"),
        help=(
            "CSV containing RTK_E and RTK_N when the ground-data file does "
            "not contain RTK coordinates. If both files contain ID, they are "
            "merged by ID; otherwise, row order is used."
        ),
    )
    parser.add_argument(
        "--grid-data",
        type=Path,
        default=Path("outputs/04_mapping/Map_Grid_Data_Corrected.csv"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("outputs/06_meanp99_holdout"),
    )

    parser.add_argument("--id-column", default="ID")
    parser.add_argument("--lai-column", default="LAI")
    parser.add_argument("--rtk-e-column", default="RTK_E")
    parser.add_argument("--rtk-n-column", default="RTK_N")
    parser.add_argument("--grid-x-column", default="Lon")
    parser.add_argument("--grid-y-column", default="Lat")
    parser.add_argument("--raw-column", default="LAI_Pred")
    parser.add_argument("--existing-corrected-column", default="LAI_Cor")

    parser.add_argument("--tree-crs", default="EPSG:4546")
    parser.add_argument("--grid-crs", default="EPSG:4326")
    parser.add_argument("--raw-lai-threshold", type=float, default=2.5)
    parser.add_argument("--effective-canopy-threshold", type=float, default=1.0)
    parser.add_argument("--clip-min", type=float, default=0.0)
    parser.add_argument("--clip-max", type=float, default=6.0)
    parser.add_argument("--background-display-value", type=float, default=0.15)
    parser.add_argument("--map-vmin", type=float, default=0.15)
    parser.add_argument("--map-vmax", type=float, default=3.75)
    parser.add_argument("--n-blocks", type=int, default=5)
    return parser.parse_args()


def require_file(path: Path, label: str) -> None:
    if not path.exists():
        raise FileNotFoundError(f"{label} not found: {path}")


def validate_columns(df: pd.DataFrame, required: Sequence[str], label: str) -> None:
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(
            f"{label} is missing required column(s): {missing}\n"
            f"Available columns: {list(df.columns)}"
        )


def clean_numeric(values: Iterable[float]) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    return array[np.isfinite(array)]


def load_ground_data(args: argparse.Namespace) -> pd.DataFrame:
    require_file(args.ground_data, "Ground data file")
    ground = pd.read_csv(args.ground_data)
    validate_columns(ground, [args.lai_column], "Ground data")

    has_coordinates = all(
        column in ground.columns
        for column in [args.rtk_e_column, args.rtk_n_column]
    )

    if not has_coordinates:
        require_file(args.spatial_data, "Spatial coordinate file")
        spatial = pd.read_csv(args.spatial_data)
        validate_columns(
            spatial,
            [args.rtk_e_column, args.rtk_n_column],
            "Spatial coordinate data",
        )

        if args.id_column in ground.columns and args.id_column in spatial.columns:
            ground = ground.merge(
                spatial[[args.id_column, args.rtk_e_column, args.rtk_n_column]],
                on=args.id_column,
                how="inner",
                validate="one_to_one",
            )
        else:
            if len(ground) != len(spatial):
                raise ValueError(
                    "Ground and spatial tables do not both contain the ID column, "
                    "and their row counts differ. Provide matching IDs or ensure "
                    "that both files use the same sample order."
                )
            ground = ground.reset_index(drop=True).copy()
            spatial = spatial.reset_index(drop=True)
            ground[args.rtk_e_column] = spatial[args.rtk_e_column].to_numpy()
            ground[args.rtk_n_column] = spatial[args.rtk_n_column].to_numpy()
            print(
                "Spatial coordinates were matched to ground samples by row order "
                "because a shared ID column was not available."
            )

    validate_columns(
        ground,
        [args.lai_column, args.rtk_e_column, args.rtk_n_column],
        "Merged ground data",
    )
    ground = ground.replace([np.inf, -np.inf], np.nan).dropna(
        subset=[args.lai_column, args.rtk_e_column, args.rtk_n_column]
    )
    for column in [args.lai_column, args.rtk_e_column, args.rtk_n_column]:
        ground[column] = ground[column].astype(float)

    if len(ground) < args.n_blocks * 2:
        raise ValueError(
            f"Only {len(ground)} complete ground samples remain; this is "
            f"insufficient for {args.n_blocks}-block evaluation."
        )
    return ground.reset_index(drop=True)


def load_grid_data(args: argparse.Namespace) -> pd.DataFrame:
    require_file(args.grid_data, "Grid prediction file")
    grid = pd.read_csv(args.grid_data)
    validate_columns(
        grid,
        [args.grid_x_column, args.grid_y_column, args.raw_column],
        "Grid data",
    )
    grid = grid.replace([np.inf, -np.inf], np.nan).dropna(
        subset=[args.grid_x_column, args.grid_y_column, args.raw_column]
    )
    for column in [args.grid_x_column, args.grid_y_column, args.raw_column]:
        grid[column] = grid[column].astype(float)
    return grid.reset_index(drop=True)


def fit_mean_p99_parameters(
    observed: np.ndarray,
    raw_predicted: np.ndarray,
) -> Dict[str, float]:
    observed = clean_numeric(observed)
    raw_predicted = clean_numeric(raw_predicted)
    if observed.size < 2 or raw_predicted.size < 2:
        raise ValueError("Insufficient data for Mean + P99 parameter estimation.")

    observed_mean = float(np.mean(observed))
    observed_p99 = float(np.percentile(observed, 99))
    raw_mean = float(np.mean(raw_predicted))
    raw_p99 = float(np.percentile(raw_predicted, 99))
    denominator = raw_p99 - raw_mean
    if abs(denominator) <= 1e-12:
        raise ValueError("Raw P99 is indistinguishable from the raw mean.")

    alpha = (observed_p99 - observed_mean) / denominator
    beta = observed_mean - alpha * raw_mean
    return {
        "alpha": alpha,
        "beta": beta,
        "observed_mean": observed_mean,
        "observed_p99": observed_p99,
        "raw_mean": raw_mean,
        "raw_p99": raw_p99,
    }


def fit_mean_shift_parameters(
    observed: np.ndarray,
    raw_predicted: np.ndarray,
) -> Dict[str, float]:
    observed = clean_numeric(observed)
    raw_predicted = clean_numeric(raw_predicted)
    if observed.size < 2 or raw_predicted.size < 2:
        raise ValueError("Insufficient data for mean-shift parameter estimation.")
    observed_mean = float(np.mean(observed))
    raw_mean = float(np.mean(raw_predicted))
    return {
        "alpha": 1.0,
        "beta": observed_mean - raw_mean,
        "observed_mean": observed_mean,
        "raw_mean": raw_mean,
    }


def apply_linear_correction(
    values: np.ndarray,
    parameters: Dict[str, float],
    clip_range: Tuple[float, float],
) -> np.ndarray:
    corrected = parameters["alpha"] * np.asarray(values, dtype=float) + parameters["beta"]
    return np.clip(corrected, clip_range[0], clip_range[1])


def distribution_metrics(
    observed: np.ndarray,
    predicted: np.ndarray,
) -> Dict[str, float]:
    observed = clean_numeric(observed)
    predicted = clean_numeric(predicted)
    if observed.size < 2 or predicted.size < 2:
        raise ValueError("Insufficient data for distributional evaluation.")

    probabilities = np.arange(0.05, 0.951, 0.05)
    observed_quantiles = np.quantile(observed, probabilities)
    predicted_quantiles = np.quantile(predicted, probabilities)
    quantile_rmse = float(
        np.sqrt(np.mean((predicted_quantiles - observed_quantiles) ** 2))
    )

    observed_mean = float(np.mean(observed))
    predicted_mean = float(np.mean(predicted))
    observed_p95 = float(np.percentile(observed, 95))
    predicted_p95 = float(np.percentile(predicted, 95))

    return {
        "N_ground": int(observed.size),
        "N_grid": int(predicted.size),
        "absolute_mean_bias": abs(predicted_mean - observed_mean),
        "absolute_p95_error": abs(predicted_p95 - observed_p95),
        "quantile_rmse": quantile_rmse,
        "wasserstein_distance": float(wasserstein_distance(observed, predicted)),
    }


def transform_grid_to_tree_crs(
    grid: pd.DataFrame,
    args: argparse.Namespace,
) -> np.ndarray:
    grid_x = grid[args.grid_x_column].to_numpy(dtype=float)
    grid_y = grid[args.grid_y_column].to_numpy(dtype=float)
    if args.grid_crs == args.tree_crs:
        transformed_x, transformed_y = grid_x, grid_y
    else:
        transformer = Transformer.from_crs(
            args.grid_crs,
            args.tree_crs,
            always_xy=True,
        )
        transformed_x, transformed_y = transformer.transform(grid_x, grid_y)

    transformed_x = np.asarray(transformed_x, dtype=float)
    transformed_y = np.asarray(transformed_y, dtype=float)
    if not np.all(np.isfinite(transformed_x)) or not np.all(np.isfinite(transformed_y)):
        raise ValueError(
            "Grid coordinate transformation produced invalid values. "
            "Check --grid-crs and --tree-crs."
        )
    return np.column_stack([transformed_x, transformed_y])


def assign_contiguous_spatial_blocks(
    ground: pd.DataFrame,
    grid: pd.DataFrame,
    args: argparse.Namespace,
) -> Tuple[pd.DataFrame, pd.DataFrame, List[float]]:
    tree_coordinates = ground[[args.rtk_e_column, args.rtk_n_column]].to_numpy(
        dtype=float
    )
    grid_coordinates = transform_grid_to_tree_crs(grid, args)

    pca = PCA(n_components=1)
    tree_scores = pca.fit_transform(tree_coordinates).ravel()
    grid_scores = pca.transform(grid_coordinates).ravel()

    sorted_indices = np.argsort(tree_scores)
    groups = np.array_split(sorted_indices, args.n_blocks)
    tree_blocks = np.empty(len(ground), dtype=int)
    for block_number, indices in enumerate(groups, start=1):
        tree_blocks[indices] = block_number

    boundaries: List[float] = []
    for index in range(args.n_blocks - 1):
        left_maximum = float(np.max(tree_scores[groups[index]]))
        right_minimum = float(np.min(tree_scores[groups[index + 1]]))
        boundaries.append((left_maximum + right_minimum) / 2.0)

    grid_blocks = np.digitize(grid_scores, np.asarray(boundaries), right=False) + 1

    ground_output = ground.copy()
    ground_output["Spatial_Score"] = tree_scores
    ground_output["Spatial_Block"] = tree_blocks

    grid_output = grid.copy()
    grid_output["Spatial_Score"] = grid_scores
    grid_output["Spatial_Block"] = grid_blocks
    return ground_output, grid_output, boundaries


def run_full_mean_p99_correction(
    ground: pd.DataFrame,
    grid: pd.DataFrame,
    args: argparse.Namespace,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, float]]:
    calibration_mask = (
        np.isfinite(grid[args.raw_column])
        & (grid[args.raw_column] > args.raw_lai_threshold)
    )
    ground_lai = ground[args.lai_column].to_numpy(dtype=float)
    calibration_raw = grid.loc[calibration_mask, args.raw_column].to_numpy(dtype=float)

    parameters = fit_mean_p99_parameters(ground_lai, calibration_raw)
    corrected = apply_linear_correction(
        grid[args.raw_column].to_numpy(dtype=float),
        parameters,
        (args.clip_min, args.clip_max),
    )

    output = grid.copy()
    output["LAI_MeanP99"] = corrected
    output["Calibration_Cell"] = calibration_mask.astype(int)
    effective_mask = calibration_mask & (
        output["LAI_MeanP99"] >= args.effective_canopy_threshold
    )
    output["Effective_Canopy_Cell"] = effective_mask.astype(int)
    output["LAI_Display"] = np.where(
        output["LAI_MeanP99"] >= args.effective_canopy_threshold,
        output["LAI_MeanP99"],
        args.background_display_value,
    )

    max_difference = np.nan
    mean_difference = np.nan
    if args.existing_corrected_column in output.columns:
        existing = pd.to_numeric(
            output[args.existing_corrected_column], errors="coerce"
        ).to_numpy(dtype=float)
        comparison_mask = np.isfinite(existing) & np.isfinite(corrected)
        if comparison_mask.any():
            difference = np.abs(existing[comparison_mask] - corrected[comparison_mask])
            max_difference = float(np.max(difference))
            mean_difference = float(np.mean(difference))

    summary = pd.DataFrame(
        [
            {
                "dataset": "Ground observed",
                "N": int(len(ground_lai)),
                "mean": float(np.mean(ground_lai)),
                "P95": float(np.percentile(ground_lai, 95)),
                "P99": float(np.percentile(ground_lai, 99)),
            },
            {
                "dataset": "Grid raw calibration domain",
                "N": int(calibration_mask.sum()),
                "mean": float(np.mean(calibration_raw)),
                "P95": float(np.percentile(calibration_raw, 95)),
                "P99": float(np.percentile(calibration_raw, 99)),
            },
            {
                "dataset": "Grid Mean + P99 effective canopy",
                "N": int(effective_mask.sum()),
                "mean": float(np.mean(output.loc[effective_mask, "LAI_MeanP99"])),
                "P95": float(
                    np.percentile(output.loc[effective_mask, "LAI_MeanP99"], 95)
                ),
                "P99": float(
                    np.percentile(output.loc[effective_mask, "LAI_MeanP99"], 99)
                ),
            },
        ]
    )

    parameters = {
        **parameters,
        "raw_lai_threshold": float(args.raw_lai_threshold),
        "effective_canopy_threshold": float(args.effective_canopy_threshold),
        "N_all_grid_cells": int(len(output)),
        "N_calibration_cells": int(calibration_mask.sum()),
        "N_effective_canopy_cells": int(effective_mask.sum()),
        "max_abs_difference_vs_existing_LAI_Cor": max_difference,
        "mean_abs_difference_vs_existing_LAI_Cor": mean_difference,
    }
    return output, summary, parameters


def run_spatial_holdout(
    ground: pd.DataFrame,
    grid: pd.DataFrame,
    args: argparse.Namespace,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, List[float]]:
    ground_blocks, grid_blocks, boundaries = assign_contiguous_spatial_blocks(
        ground, grid, args
    )
    calibration_domain = (
        np.isfinite(grid_blocks[args.raw_column])
        & (grid_blocks[args.raw_column] > args.raw_lai_threshold)
    )

    fold_rows: List[Dict[str, float]] = []
    parameter_rows: List[Dict[str, float]] = []

    for held_out_block in range(1, args.n_blocks + 1):
        train_ground = ground_blocks["Spatial_Block"] != held_out_block
        test_ground = ground_blocks["Spatial_Block"] == held_out_block
        train_grid = calibration_domain & (
            grid_blocks["Spatial_Block"] != held_out_block
        )
        test_grid = calibration_domain & (
            grid_blocks["Spatial_Block"] == held_out_block
        )

        observed_train = ground_blocks.loc[train_ground, args.lai_column].to_numpy(
            dtype=float
        )
        observed_test = ground_blocks.loc[test_ground, args.lai_column].to_numpy(
            dtype=float
        )
        raw_train = grid_blocks.loc[train_grid, args.raw_column].to_numpy(dtype=float)
        raw_test = grid_blocks.loc[test_grid, args.raw_column].to_numpy(dtype=float)

        if observed_test.size < 2 or raw_test.size < 2:
            raise ValueError(f"Held-out block {held_out_block} has insufficient data.")

        mean_shift_parameters = fit_mean_shift_parameters(observed_train, raw_train)
        mean_p99_parameters = fit_mean_p99_parameters(observed_train, raw_train)

        predictions = {
            "Direct upscaling": raw_test,
            "Mean-shift correction": apply_linear_correction(
                raw_test,
                mean_shift_parameters,
                (args.clip_min, args.clip_max),
            ),
            "Mean + P99 correction": apply_linear_correction(
                raw_test,
                mean_p99_parameters,
                (args.clip_min, args.clip_max),
            ),
        }

        for method, predicted in predictions.items():
            fold_rows.append(
                {
                    "held_out_block": held_out_block,
                    "method": method,
                    "N_train_ground": int(train_ground.sum()),
                    "N_test_ground": int(test_ground.sum()),
                    "N_train_grid": int(train_grid.sum()),
                    "N_test_grid": int(test_grid.sum()),
                    **distribution_metrics(observed_test, predicted),
                }
            )

        parameter_rows.extend(
            [
                {
                    "held_out_block": held_out_block,
                    "method": "Mean-shift correction",
                    **mean_shift_parameters,
                },
                {
                    "held_out_block": held_out_block,
                    "method": "Mean + P99 correction",
                    **mean_p99_parameters,
                },
            ]
        )

    fold_metrics = pd.DataFrame(fold_rows)
    parameter_table = pd.DataFrame(parameter_rows)
    metric_columns = [
        "absolute_mean_bias",
        "absolute_p95_error",
        "quantile_rmse",
        "wasserstein_distance",
    ]

    summary_rows: List[Dict[str, float]] = []
    for method in METHOD_ORDER:
        subset = fold_metrics.loc[fold_metrics["method"] == method]
        row: Dict[str, float] = {"method": method, "N_folds": int(len(subset))}
        for metric in metric_columns:
            row[f"{metric}_mean"] = float(subset[metric].mean())
            row[f"{metric}_sd"] = float(subset[metric].std(ddof=1))
        summary_rows.append(row)

    summary = pd.DataFrame(summary_rows)
    direct = summary.loc[summary["method"] == "Direct upscaling"].iloc[0]
    for metric in metric_columns:
        baseline = float(direct[f"{metric}_mean"])
        summary[f"{metric}_reduction_percent_vs_direct"] = (
            (baseline - summary[f"{metric}_mean"]) / baseline * 100.0
        )

    display_names = {
        "absolute_mean_bias": "Absolute mean bias",
        "absolute_p95_error": "Absolute P95 error",
        "quantile_rmse": "Quantile RMSE",
        "wasserstein_distance": "Wasserstein distance",
    }
    manuscript_rows: List[Dict[str, str]] = []
    for _, row in summary.iterrows():
        output_row: Dict[str, str] = {"Mapping strategy": str(row["method"])}
        for metric, display_name in display_names.items():
            output_row[display_name] = (
                f"{row[f'{metric}_mean']:.3f} ± {row[f'{metric}_sd']:.3f}"
            )
        manuscript_rows.append(output_row)

    return (
        fold_metrics,
        summary,
        pd.DataFrame(manuscript_rows),
        parameter_table,
        boundaries,
    )


def density_curve(values: np.ndarray, x_axis: np.ndarray) -> np.ndarray:
    values = clean_numeric(values)
    if values.size < 2 or np.std(values) <= 1e-12:
        return np.zeros_like(x_axis)
    return gaussian_kde(values)(x_axis)


def plot_corrected_map(
    grid: pd.DataFrame,
    args: argparse.Namespace,
    output_path: Path,
) -> None:
    plot_data = grid.dropna(
        subset=[args.grid_x_column, args.grid_y_column, "LAI_Display"]
    )
    figure, axis = plt.subplots(figsize=(9, 8))
    scatter = axis.scatter(
        plot_data[args.grid_x_column],
        plot_data[args.grid_y_column],
        c=plot_data["LAI_Display"],
        s=2,
        marker="s",
        linewidths=0,
        cmap="RdYlGn",
        vmin=args.map_vmin,
        vmax=args.map_vmax,
    )
    colorbar = figure.colorbar(scatter, ax=axis, fraction=0.035, pad=0.03)
    colorbar.set_label("Effective LAI")
    axis.set_xlabel(args.grid_x_column)
    axis.set_ylabel(args.grid_y_column)
    axis.set_title("Mean + P99 corrected Effective LAI map")
    axis.set_aspect("equal", adjustable="box")
    figure.tight_layout()
    figure.savefig(output_path, dpi=600, bbox_inches="tight")
    plt.close(figure)


def plot_distribution_comparison(
    ground: pd.DataFrame,
    grid: pd.DataFrame,
    args: argparse.Namespace,
    output_path: Path,
) -> None:
    ground_lai = ground[args.lai_column].to_numpy(dtype=float)
    raw = grid.loc[grid["Calibration_Cell"] == 1, args.raw_column].to_numpy(
        dtype=float
    )
    corrected = grid.loc[
        grid["Effective_Canopy_Cell"] == 1, "LAI_MeanP99"
    ].to_numpy(dtype=float)

    minimum = min(float(np.min(ground_lai)), float(np.min(raw)), float(np.min(corrected)))
    maximum = max(float(np.max(ground_lai)), float(np.max(raw)), float(np.max(corrected)))
    x_axis = np.linspace(minimum, maximum, 400)

    figure, axis = plt.subplots(figsize=(7, 6))
    axis.plot(x_axis, density_curve(ground_lai, x_axis), linewidth=2, label="Ground observed")
    axis.plot(x_axis, density_curve(raw, x_axis), linestyle="--", linewidth=2, label="Grid raw")
    axis.plot(x_axis, density_curve(corrected, x_axis), linewidth=2, label="Grid corrected")
    axis.set_xlabel("Effective LAI")
    axis.set_ylabel("Density")
    axis.legend(frameon=False)
    axis.grid(True, linestyle=":", alpha=0.4)
    figure.tight_layout()
    figure.savefig(output_path, dpi=600, bbox_inches="tight")
    plt.close(figure)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    ground = load_ground_data(args)
    grid = load_grid_data(args)

    print("=" * 72)
    print("Mean + P99 correction and spatial holdout evaluation")
    print("=" * 72)
    print(f"Ground samples: {len(ground)}")
    print(f"Grid cells:     {len(grid)}")
    print(f"Output folder:  {args.output_dir}")

    corrected_grid, full_statistics, full_parameters = run_full_mean_p99_correction(
        ground, grid, args
    )
    (
        fold_metrics,
        holdout_summary,
        manuscript_table,
        holdout_parameters,
        boundaries,
    ) = run_spatial_holdout(ground, grid, args)

    corrected_grid.to_csv(
        args.output_dir / "Map_Grid_Data_MeanP99_Final.csv", index=False
    )
    full_statistics.to_csv(
        args.output_dir / "MeanP99_Full_Distribution_Statistics.csv", index=False
    )
    fold_metrics.to_csv(
        args.output_dir / "Spatial_Holdout_Fold_Metrics.csv", index=False
    )
    holdout_summary.to_csv(
        args.output_dir / "Spatial_Holdout_Summary.csv", index=False
    )
    manuscript_table.to_csv(
        args.output_dir / "Table6_Spatial_Holdout_Mean_SD.csv", index=False
    )
    holdout_parameters.to_csv(
        args.output_dir / "Spatial_Holdout_Correction_Parameters.csv", index=False
    )

    with open(
        args.output_dir / "MeanP99_Full_Correction_Parameters.json",
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(full_parameters, file, indent=2)

    with open(
        args.output_dir / "Spatial_Block_Boundaries.json",
        "w",
        encoding="utf-8",
    ) as file:
        json.dump(
            {
                "n_blocks": args.n_blocks,
                "boundaries_on_first_principal_spatial_axis": boundaries,
                "tree_crs": args.tree_crs,
                "grid_crs": args.grid_crs,
            },
            file,
            indent=2,
        )

    ground_blocks, grid_blocks, _ = assign_contiguous_spatial_blocks(
        ground, grid, args
    )
    ground_blocks.to_csv(
        args.output_dir / "Ground_Spatial_Block_Assignment.csv", index=False
    )
    grid_blocks[
        [
            args.grid_x_column,
            args.grid_y_column,
            args.raw_column,
            "Spatial_Score",
            "Spatial_Block",
        ]
    ].to_csv(
        args.output_dir / "Grid_Spatial_Block_Assignment.csv", index=False
    )

    plot_corrected_map(
        corrected_grid,
        args,
        args.output_dir / "Fig_MeanP99_Corrected_LAI_Map.png",
    )
    plot_distribution_comparison(
        ground,
        corrected_grid,
        args,
        args.output_dir / "Fig_MeanP99_Distribution_Comparison.png",
    )

    print("\nFull-data Mean + P99 parameters:")
    print(json.dumps(full_parameters, indent=2))
    print("\nManuscript-style spatial holdout table:")
    print(manuscript_table.to_string(index=False))
    print("\nCompleted.")


if __name__ == "__main__":
    main()
