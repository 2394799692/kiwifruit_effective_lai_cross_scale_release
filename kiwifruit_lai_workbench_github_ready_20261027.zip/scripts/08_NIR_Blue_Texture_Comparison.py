"""Compare NIR/blue texture combinations with the same Linear SVR configuration.

Run from repository root:
    python scripts/08_NIR_Blue_Texture_Comparison.py

Outputs a two-row summary under outputs/08_nir_blue_texture/.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.model_selection import LeaveOneOut, KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "LAI_RGB_Texture_Comparison_82.csv"
OUTPUT_DIR = ROOT / "outputs" / "08_nir_blue_texture"


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(DATA).dropna(subset=["LAI", "crown radius", "Tex_Cor", "B_Tex_Cor"])
    y = df["LAI"].to_numpy()
    rows = []
    for label, col in (("NIR", "Tex_Cor"), ("Blue", "B_Tex_Cor")):
        X = df[["crown radius", col]]
        model = make_pipeline(StandardScaler(), SVR(kernel="linear", C=0.1, epsilon=0.05))
        loo = cross_val_predict(model, X, y, cv=LeaveOneOut(), n_jobs=1)
        r2_5 = []
        for repeat in range(100):
            cv = KFold(n_splits=5, shuffle=True, random_state=2026 + repeat)
            pred = cross_val_predict(model, X, y, cv=cv, n_jobs=1)
            r2_5.append(r2_score(y, pred))
        rows.append(dict(
            Texture=label, N=len(df),
            LOOCV_R2=r2_score(y, loo),
            LOOCV_RMSE=float(np.sqrt(mean_squared_error(y, loo))),
            Repeated_5fold_R2_mean=float(np.mean(r2_5)),
            Repeated_5fold_R2_SD=float(np.std(r2_5, ddof=1)),
            C=0.1, epsilon=0.05,
        ))
    out=pd.DataFrame(rows)
    out.to_csv(OUTPUT_DIR / "NIR_Blue_Texture_Comparison.csv", index=False)
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
