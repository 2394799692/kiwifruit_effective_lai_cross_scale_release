"""
Distribution analysis for MAUP-related cross-scale correction.

This script compares the distribution of ground-observed LAI, raw grid-level LAI,
and Mean+P99-corrected grid-level LAI. It is intended to validate whether the
cross-scale correction reduces the systematic bias caused by grid-based upscaling.

Expected inputs:
    data/LAI_Final_17cols.csv
    outputs/04_mapping/Map_Grid_Data_Corrected.csv

Main outputs:
    distribution_statistics.csv
    Fig_Distribution_Density.png
    Fig_Distribution_Boxplot.png
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Analyze distribution consistency after cross-scale correction.")
    parser.add_argument("--ground-data", type=Path, default=Path("data/LAI_Final_17cols.csv"))
    parser.add_argument("--grid-data", type=Path, default=Path("outputs/04_mapping/Map_Grid_Data_Corrected.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/05_maup_analysis"))
    parser.add_argument("--target", type=str, default="LAI")
    parser.add_argument("--raw-column", type=str, default="LAI_Pred")
    parser.add_argument("--corrected-column", type=str, default="LAI_Cor")
    parser.add_argument("--raw-lai-min", type=float, default=2.5)
    parser.add_argument("--corrected-display-min", type=float, default=1.0)
    return parser.parse_args()


def validate_columns(df: pd.DataFrame, required: list[str]) -> None:
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required column(s): {missing}")


def summary_statistics(values: np.ndarray) -> Dict[str, float]:
    values = values[np.isfinite(values)]
    return {
        "n": int(len(values)),
        "mean": float(np.mean(values)),
        "std": float(np.std(values, ddof=1)),
        "median": float(np.median(values)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
        "p95": float(np.percentile(values, 95)),
        "p99": float(np.percentile(values, 99)),
    }


def plot_density(ground: np.ndarray, raw: np.ndarray, corrected: np.ndarray, output_path: Path) -> None:
    plt.figure(figsize=(7, 6))
    sns.kdeplot(ground, fill=True, alpha=0.2, linewidth=2.0, label="Ground observed")
    sns.kdeplot(raw, linestyle="--", linewidth=2.0, label="Grid raw")
    sns.kdeplot(corrected, linestyle="-", linewidth=2.0, label="Grid corrected")
    plt.xlabel("LAI value", fontweight="bold")
    plt.ylabel("Density", fontweight="bold")
    plt.xlim(0, 4.5)
    plt.legend(frameon=False)
    plt.grid(True, linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(output_path, dpi=600, bbox_inches="tight")
    plt.close()


def plot_boxplot(ground: np.ndarray, raw: np.ndarray, corrected: np.ndarray, output_path: Path) -> None:
    fig, ax = plt.subplots(figsize=(7, 6))
    labels = ["Ground\nobserved", "Grid\nraw", "Grid\ncorrected"]
    flier_props = dict(marker="o", markerfacecolor="gray", markeredgecolor="none", markersize=4, alpha=0.6)
    box = ax.boxplot(
        [ground, raw, corrected],
        patch_artist=True,
        labels=labels,
        widths=0.5,
        flierprops=flier_props,
        medianprops=dict(color="black", linewidth=1.5),
        boxprops=dict(linewidth=1.2),
        whiskerprops=dict(linewidth=1.2),
        capprops=dict(linewidth=1.2),
    )
    for patch in box["boxes"]:
        patch.set_facecolor("white")
        patch.set_edgecolor("black")
    ax.set_ylabel("LAI value", fontweight="bold")
    ax.grid(True, axis="y", linestyle=":", alpha=0.4)
    plt.tight_layout()
    plt.savefig(output_path, dpi=600, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    if not args.ground_data.exists():
        raise FileNotFoundError(f"Ground data file not found: {args.ground_data}")
    if not args.grid_data.exists():
        raise FileNotFoundError(
            f"Grid data file not found: {args.grid_data}. Run 04_Mapping_and_Correction.py first."
        )

    ground_df = pd.read_csv(args.ground_data)
    grid_df = pd.read_csv(args.grid_data)
    validate_columns(ground_df, [args.target])
    validate_columns(grid_df, [args.raw_column, args.corrected_column])

    ground = ground_df[args.target].astype(float).values
    raw_all = grid_df[args.raw_column].astype(float).values
    corrected_all = grid_df[args.corrected_column].astype(float).values

    raw_mask = np.isfinite(raw_all) & (raw_all > args.raw_lai_min)
    raw = raw_all[raw_mask]
    corrected_temp = corrected_all[raw_mask]
    corrected = corrected_temp[np.isfinite(corrected_temp) & (corrected_temp > args.corrected_display_min)]

    stats = pd.DataFrame(
        [
            {"dataset": "Ground observed", **summary_statistics(ground)},
            {"dataset": "Grid raw", **summary_statistics(raw)},
            {"dataset": "Grid corrected", **summary_statistics(corrected)},
        ]
    )
    stats.to_csv(args.output_dir / "distribution_statistics.csv", index=False)

    plot_density(ground, raw, corrected, args.output_dir / "Fig_Distribution_Density.png")
    plot_boxplot(ground, raw, corrected, args.output_dir / "Fig_Distribution_Boxplot.png")

    print("MAUP correction analysis completed.")
    print(stats.to_string(index=False))
    print(f"Outputs saved to: {args.output_dir}")


if __name__ == "__main__":
    main()
