# Public release notes

This publication-oriented package was reorganized from the supplied experimental-code archive for GitHub release.

Key changes:

- retained the six core Python scripts and the processed 82-sample modeling table;
- added detailed README, method-to-code mapping, repository-scope documentation, usage/IP notice, citation metadata, examples, and data-access notes;
- added `pyproj` to the dependency list because it is required by the spatial holdout script;
- aligned the reference grid-level GLCM correlation implementation with the manuscript's four-direction setting (0°, 45°, 90°, 135°) and 32-level quantization;
- made the grid-scale crown-radius proxy calibration explicit in Script 4 instead of silently relying on a median-radius fallback; the fallback is now demonstration-only and must be requested explicitly;
- removed machine-specific paths and confirmed that all scripts compile and expose command-line help;
- added the CNIPA acceptance notice and substantive-examination notice for Chinese invention patent application 202610573929.6;
- did not include an open-source license in this release; see `USAGE_NOTICE.md` for the patent and reuse notice.
