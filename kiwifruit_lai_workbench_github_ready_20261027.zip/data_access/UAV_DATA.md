# UAV and spatial data access

Large UAV orthomosaics, tree-level RTK coordinates, intermediate raster products, and full orchard grid-prediction tables are not bundled with this lightweight GitHub release.

The public repository includes the processed 82-sample modeling table needed for the tree-scale analyses and reference implementations for the mapping and spatial-holdout stages. Users who need additional research data for academic verification, methodological comparison, or collaboration may contact:

**Dr. Wenjie Li**  
Email: **17395844880@163.com**

Availability of additional files is subject to project, intellectual-property, storage, and collaboration requirements.
